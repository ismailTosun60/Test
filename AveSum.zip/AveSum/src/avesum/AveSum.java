/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avesum;
import java.util.Scanner;

/**
 *
 * @author itosu
 */
public class AveSum {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("değer gir");
        Scanner input = new Scanner(System.in);
        
        double summerize =0.0;
        int count =0;
        double average;
        
        int value;
        
        
        while(true){
        
            value = input.nextInt();
        if( value %10==0){
            System.out.println("Lütfen 10 ve katlarını girmeyiniz");
            
           continue; }
            
        
        summerize += value;
            
            count++;
            
            average = summerize/count;
            System.out.println("sum:"+summerize+"\nave:"+average);
            if(summerize>=100){
                System.out.println("işlem tamamlandı");
            break;}
            
            
            
            
        
        
        
        
        
        }
    
    
    
    
    }
    
}
